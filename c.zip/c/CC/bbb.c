#include <stdio.h>
#include <stdlib.h>
unsigned float_i2f(int);
int main()
{

  unsigned d;
  d = float_i2f(-11);
  printf("\n float_i2f is :%d \n",d);
}

unsigned float_i2f(int x) {
  if (x == 0)
    return 0x0;
  else if (x == 0x80000000)
    return 0xcf000000;
  else {
    int sign, abs, exp, frac; /* values to represent the number */
    int roundoff, pad, num_digits, mask, half_uls; /* values for rounding */
    int tmin = 0x80000000;
    sign = x &amp; 0x80000000;
    abs = sign? -x : x;
    frac = abs;
    exp = 0;
    roundoff = 0;
    pad = 0;

    /* calculate the exp */
    while (abs >>= 1) {
        exp ++;
    }

    num_digits = exp - 23;

    if (exp > 23) {
        /* round numbers with more than 23 significant digits */
        mask = ~(tmin >> (31 - num_digits));
        roundoff = frac &amp; mask;
        half_uls = 0x1 &lt;&lt; (num_digits - 1);          if (roundoff == half_uls) {             if (frac >> num_digits & 0x1)
                pad = 1;
        } else {
            pad = roundoff > half_uls;
        }
        unsigned float_i2f(int x) {
  if (x == 0)
    return 0x0;
  else if (x == 0x80000000)
    return 0xcf000000;
  else {
    int sign, abs, exp, frac; /* values to represent the number */
    int roundoff, pad, num_digits, mask, half_uls; /* values for rounding */
    int tmin = 0x80000000;
    sign = x &amp; 0x80000000;
    abs = sign? -x : x;
    frac = abs;
    exp = 0;
    roundoff = 0;
    pad = 0;

    /* calculate the exp */
    while (abs >>= 1) {
        exp ++;
    }

    num_digits = exp - 23;

    if (exp > 23) {
        /* round numbers with more than 23 significant digits */
        mask = ~(tmin >> (31 - num_digits));
        roundoff = frac &amp; mask;
        half_uls = 0x1 &lt;&lt; (num_digits - 1);          if (roundoff == half_uls) {             if (frac >> num_digits & 0x1)
                pad = 1;
        } else {
            pad = roundoff > half_uls;
        }

        frac = (frac >> num_digits) + pad;

        if (frac &amp; 0x01000000)
            exp++;
    }
    else
        frac = frac &lt;&lt; (-num_digits);

    frac = frac &amp; 0x7fffff; /* set the sign and exponent bits to zero */

    exp += 0x7f; /* add the bias to the exp */

    return sign | (exp &lt;&lt; 23) | frac;
  }
}
