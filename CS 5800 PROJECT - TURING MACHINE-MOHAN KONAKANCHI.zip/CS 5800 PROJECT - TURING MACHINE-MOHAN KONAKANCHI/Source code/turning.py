import sys
import string

class TuringMachine_simulator:
    def __init__(sf,st,w_h,t_l):
        sf.st = st
        sf.w_h = w_h
        sf.t_l = t_l

    def getState(sf):
        return sf.st

    def getHead(sf):
        return sf.w_h
    
    def getList(sf):
        return sf.t_l

    # Table of rules!
    def updateMachine(sf):
        # Initial State
        if (sf.st == 'pandu'):
            if (sf.t_l[sf.w_h] != 0):
              # SELF STATE 
                char_read = sf.t_l[sf.w_h]
                char_index = c_l.index(char_read)
                sf.st = ''.join(['p',str(char_index)])
                # zero is assigned
                sf.t_l[sf.w_h] = 0
                # moves to words right
                sf.w_h += 1
            else:
                # STATE 
                sf.st = 'dimple'
                # zero is unchanged
                sf.t_l[sf.w_h] = 0
                # moving right
                sf.w_h += 1
    
        elif (sf.st.startswith('p')):
            if (sf.t_l[sf.w_h]!=0):
                # unchanged state
                sf.st = sf.st
                # unchanged write
                sf.t_l[sf.w_h] = sf.t_l[sf.w_h]
                # moving right side
                sf.w_h += 1
            else:
                # state string r
                sf.st = ''.join(['r',sf.st[1:]])
                # zero unchanged
                sf.t_l[sf.w_h] = 0
                # moving left side
                sf.w_h -= 1
                    
        elif (sf.st.startswith('r')):
            char_read = c_l[int(sf.st[1:])]
             # string is required for odd length
            if (sf.t_l[sf.w_h] != char_read and sf.t_l[sf.w_h] != 0):
                # bunny start state
                sf.st = 'bunny'
                
                sf.t_l[sf.w_h] = sf.t_l[sf.w_h] # writing
                # moving left side
                sf.w_h -= 1
            else:
                # new state
                sf.st = 'vp'
                # writing zero
                sf.t_l[sf.w_h] = 0
                # moving left
                sf.w_h -= 1
                
        elif (sf.st == 'vp'):
            if (sf.t_l[sf.w_h] != 0):
                # unchanged state
                sf.st = 'vp'
                # unchanged writing state
                sf.t_l[sf.w_h] = sf.t_l[sf.w_h]
                # string moving to left
                sf.w_h -= 1
            else:
                # new state pandu
                sf.st = 'pandu'
                # writing zero
                sf.t_l[sf.w_h] = 0
                #moving right
                sf.w_h += 1

# allow  the string 
c_l = list(string.ascii_lowercase)
c_l.append(' ') # allowing



i_s = input('Enter the turning machine string: ') # string inialization 
print ('***Checking***'),i_s
print 
print ('#############################################################')

i_l = list(i_s)

# check the characters of the all string
for i in i_l:
    if i not in c_l:
        print ('Invalid string Enter a valid string')
        sys.exit()

# string append
i_l.append(0);

# turning maching started
i_write= 0
i_state = 'pandu' # starting state
i_tapeList = i_l

# class is initialize
runningTM = TuringMachine_simulator(i_state,i_write,i_tapeList)
print (runningTM.getState(),runningTM.getHead(),runningTM.getList())

# turing machine is running
ctr=0
while runningTM.getState() != 'dimple' and runningTM.getState() != 'bunny' and ctr < 1000:
    runningTM.updateMachine();
    print (runningTM.getList(),runningTM.getHead(),runningTM.getState())
    ctr += 1
print ('*******************************************************')
print

# Printout result
if (runningTM.getState() == 'dimple'):
    print
    print ('NO:OF STEPS=',ctr,i_s)
    print ('-----------------------------------------------------')
    print ('* THE GIVEN STRING IS ACCEPETED BY TUNING MACHINE  *')
    print ('-----------------------------------------------------')
else:
    print ('NO:OF STEPS=',ctr,i_s)
    print ('-----------------------------------------------------')
    print ('*  THE GIVEN STRING IS REJECTED BY TUNING MACHINE  *')
    print ('-----------------------------------------------------')

