#include <stdio.h>

#include <string.h>
 
#define STATES  99

#define SYMBOLS 20
 
int N_symbols;  // its for number of input symbols

int N_DFA_states;   // DFA states

char *DFA_finals;   // finite state

int DFAtab[STATES][SYMBOLS];
 
char StateName[STATES][STATES+1];   // state name table
 
int N_optDFA_states;    // This for number of optimization state.

int OptDFA[STATES][SYMBOLS]; //its for optmized dfa

char NEW_finals[STATES+1];

void main()
{
    load_DFA_table();
    print_dfa_table(DFAtab, N_DFA_states, N_symbols, DFA_finals);
 
    N_optDFA_states = optimize_DFA(DFAtab, N_DFA_states,
            N_symbols, DFA_finals, StateName, OptDFA);
    get_NEW_finals(NEW_finals, DFA_finals, StateName, N_optDFA_states);
 
    print_dfa_table(OptDFA, N_optDFA_states, N_symbols, NEW_finals);
}

void print_equiv_classes(char stnt[][STATES+1], int n) //printing the equivalance state
{
    int i;
 
    printf("\nEQUIV. CLASS CANDIDATE ==>");
    for (i = 0; i < n; i++)
        printf(" %d:[%s]", i, stnt[i]);		// find every state and prints it
    printf("\n");
}

 
/*
    Gives use transition table and format is
	A, B, C, D,..........
*/

void print_dfa_table(
    int tab[][SYMBOLS], // transition table for DFA
    int nstates,    // no:of states in dfa
    int nsymbols,   /* no:of inputs symbols required*/
    char *finals)
{
    int i, j;
 
    puts("\nDFA: STATE TRANSITION TABLE");
 
    //inputs are in form of numbers 0,1.......

    printf("     | ");				                // getting table format
    for (i = 0; i < nsymbols; i++) 				// loop for number of states
	printf("  %c  ", '0'+i);
     	printf("\n-----+--");
    for (i = 0; i < nsymbols; i++) 				// loop for number of states
	printf("-----");
   	printf("\n");						// getting table format
 
    for (i = 0; i < nstates; i++)
	{
        	printf("  %c  | ", 'A'+i);  			// print the states
       		for (j = 0; j < nsymbols; j++)
           	printf("  %c  ", tab[i][j]);    	//print the next state
        	printf("\n");
	}
    printf("Final states = %s\n", finals);			//print the final state
}
 
//Table initialization is down here

 
void load_DFA_table()
{
    DFAtab[0][0] = 'A'; DFAtab[0][1] = 'C';
    DFAtab[1][0] = 'E'; DFAtab[1][1] = 'F';
    DFAtab[2][0] = 'B'; DFAtab[2][1] = 'B';
    DFAtab[3][0] = 'F'; DFAtab[3][1] = 'E';
    DFAtab[4][0] = 'D'; DFAtab[4][1] = 'F';
    DFAtab[5][0] = 'D'; DFAtab[5][1] = 'E';
 
    DFA_finals = "EF";
    N_DFA_states = 6;
    N_symbols = 2;

}
 
//getting the strings for current state
   
void get_next_state(char *nextstates, char *cur_states,

int dfa[STATES][SYMBOLS], int symbol)
{
    int i, ch;
 
    for (i = 0; i < strlen(cur_states); i++)
        *nextstates++ = dfa[cur_states[i]-'A'][symbol];
   	*nextstates = '\0';
}
 
/*
    //class equivalace get 0, 1, 2....
*/

char equiv_class_ndx(char ch, char stnt[][STATES+1], int n) 
{
    int i;
 
    for (i = 0; i < n; i++)
        if (strchr(stnt[i], ch)) return i+'0'; //NOT defined next state*/
	    return -1;  
}
 
/*
  
        //If next state is unique, return next state --> 'A/B/C/...'
    
*/

char is_one_nextstate(char *s)
{
    char equiv_class;   // class for first equivalance
 
    while (*s == '@') s++;
    equiv_class = *s++; //class  for index equivalance
 
    while (*s)
	{
        	if (*s != '@' && *s != equiv_class) return 0;  //'s' is a '0/1' string: state-id's
        	s++;
 	}
 
    return equiv_class;                                          // char_type next state.
}
 
int state_index(char *state, char stnt[][STATES+1], int n, int *pn,int cur)    /* cur is used for printing*/
{
    int i;
    char state_flags[STATES+1]; 			// specify next state info //
 
    if (!*state) return -1; 				// find for next state
 
    for (i = 0; i < strlen(state); i++)
        state_flags[i] = equiv_class_ndx(state[i], stnt, n);    //set flags for equiv class
 	state_flags[i] = '\0';
 
    	printf("   %d:[%s]\t--> [%s] (%s)\n", cur, stnt[cur], state, state_flags);    //gives the states and flags
 
    if (i=is_one_nextstate(state_flags))
        return i-'0';  				           // find next deterministic states //
    else
    {
        strcpy(stnt[*pn], state_flags);                    // specify state information
        return (*pn)++;
    }
}
 
// identify the final and non final states 

int init_equiv_class(char statename[][STATES+1], int n, char *finals)
{
    int i, j;
 
    if (strlen(finals) == n)
    { 
        strcpy(statename[0], finals);          //specify the all state and final state
        return 1;
    }
 
    strcpy(statename[1], finals);   		// specify the final state
 
    for (i=j=0; i < n; i++) 
	{
        	if (i == *finals-'A') {
            	finals++;
        } 
	else statename[0][j++] = i+'A';
    }
    statename[0][j] = '\0';
 
    return 2;
}
 
//here we get optimized dfa
    
int get_optimized_DFA(char stnt[][STATES+1], int n,
int dfa[][SYMBOLS], int n_sym, int newdfa[][SYMBOLS])
{
    int n2=n;                  /*number of state-division info */
    int i, j;
    char nextstate[STATES+1];
 
    for (i = 0; i < n; i++) 
    {    /* for each pseudo-DFA state */
        for (j = 0; j < n_sym; j++)
	 {    /* for each input symbol */
            get_next_state(nextstate, stnt[i], dfa, j);
            newdfa[i][j] = state_index(nextstate, stnt, n, &n2, i)+'A';
        }
    }
 
    return n2;
}
 

void chr_append(char *s, char ch) //declaring the character
{
    int n=strlen(s);
 
    *(s+n) = ch;
    *(s+n+1) = '\0';
}
 
void sort(char stnt[][STATES+1], int n)	//sorting the characters
{
    int i, j;
    char temp[STATES+1];
 
    for (i = 0; i < n-1; i++)		//loop to find out the set of variables
        for (j = i+1; j < n; j++)
            if (stnt[i][0] > stnt[j][0])
	    {
                strcpy(temp, stnt[i]);
                strcpy(stnt[i], stnt[j]);	//copying the variables
                strcpy(stnt[j], temp);
            }
}
int optimize_DFA(
    int dfa[][SYMBOLS], //transactrion table for dfa
    int n_dfa,  	// find the number of dfa's
    int n_sym,  	//input symbol varable
    char *finals,   	// final state for dfa
    char stnt[][STATES+1],  // state name is replaced
    int newdfa[][SYMBOLS])  // for new min dfa
{
    char nextstate[STATES+1];
    int n;  // new states for dfa
    int n2; //<n2> number of dividing states
 
    n = init_equiv_class(stnt, n_dfa, finals);	//find states symbols and final states
 
    while (1) 
	{
        	print_equiv_classes(stnt, n);
        	n2 = get_optimized_DFA(stnt, n, dfa, n_sym, newdfa);	//optmization of dfa
        	if (n != n2)
        	    n = set_new_equiv_class(stnt, n, newdfa, n_sym, n_dfa);// set the new of new states to=n
        	else break; 
    	}
 
    return n;   /* number of DFA states */
}
 

int split_equiv_class(char stnt[][STATES+1],	//split equivalance class
    int i1, //index of 'i1
    int i2, //index of equiv
    int n,  // number of entries
    int n_dfa)  //dfa entries
{
    char *old=stnt[i1], *vec=stnt[i2];	//declaring the old and new state
    int i, n2, flag=0;
    char newstates[STATES][STATES+1];   // creating sub class
 
    for (i=0; i < STATES; i++) newstates[i][0] = '\0';
 
    for (i=0; vec[i]; i++)
        chr_append(newstates[vec[i]-'0'], old[i]);  //checks for new state
 
    for (i=0, n2=n; i < n_dfa; i++) 
	{
       	    if (newstates[i][0]) 
		{
            	   if (!flag) 
			{    
                		strcpy(stnt[i1], newstates[i]); //copy the string and overwrite the parent class with new state
               			 flag = 1;   // set flag to one
            		} 
		    else  
                    strcpy(stnt[n2++], newstates[i]); //copy the new state and replace
       		 }
    	 }
 
    sort(stnt, n2); // sorting the equivalance class
 
    return n2;  // return the equivalance number
}
 

int set_new_equiv_class(char stnt[][STATES+1], int n, int newdfa[][SYMBOLS], int n_sym, int n_dfa)	//creating new equvalance state
{
    int i, j, k;
 
    for (i = 0; i < n; i++)	//looping the variables
	 {
            for (j = 0; j < n_sym; j++) 
	    {
            	k = newdfa[i][j]-'A';   		//indexing variaable =k
            	if (k >= n)  		// fin the equivalance class >=n
                return split_equiv_class(stnt, i, k, n, n_dfa);  //return the required formart
             }
    	}
 
    return n;
} 

void get_NEW_finals(
    char *newfinals,    //new dfa final state
    char *oldfinals,    // old dfa scource
    char stnt[][STATES+1],  // state name variable
    int n)  // number
{
    int i;
 
    for (i = 0; i < n; i++)
        if (is_subset(oldfinals, stnt[i])) *newfinals++ = i+'A';// checks for new loops
    *newfinals++ = '\0';
}

int is_subset(char *s, char *t)
{
    int i;
 
    for (i = 0; *t; i++)
        if (!strchr(s, *t++)) return 0;// finds the sub string variables
    return 1;
}
 
