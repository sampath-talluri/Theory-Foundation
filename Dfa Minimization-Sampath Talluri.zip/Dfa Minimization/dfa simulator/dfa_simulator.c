#include <stdio.h>

#include <string.h>

#include <stdlib.h>

int **trans_Map; //transition mapping

int **parti_trans_Map; //partition transition mapping

long int reachable; //reachable state

long int final_Sts; //final states

long int *P; //pointer

long int all_Sts; //all states

long int non_final_Sts; //non final states

int start_sts; //starting state

int main()
{
	final_Sts = 0; //no states start with zero
	all_Sts = 0;
			//no states
	trans_Map = (int**)malloc(64*sizeof(int*));			//transition mapping
	for (int i = 0; i < 64; i++)
	{
		trans_Map[i] = (int*) malloc(26*sizeof(int));		//memory allocation for it
		for (int j = 0; j < 26; j++)
		{
			trans_Map[i][j] = -1;		//mapping
		}
	}		// Here we Initialize our transition maps.

	parti_Trans_Map = (int**)malloc(64*sizeof(int*));
	for (int i = 0; i < 64; i++)
	{
		part_Trans_Map[i] = (int*) malloc(26*sizeof(int));		//partition transition mapping
		for (int j = 0; j < 26; j++)
		{					//memory allocation for it
			parti_trans_Map[i][j] = -1;
		}
	}

	
	char buff[125];
	fgets(buff, sizeof(buff), stdin);			// start state is ready
	char *p = strtok(buff, " ");
	start_sts = atoi(p);

	
	fgets(buff, sizeof(buff), stdin);
	p = strtok(buff, " ");					// final states is ready
	while (p != NULL)
	{
		int state = atoi(p);
		final_Sts |= 1 << (state);
		p = strtok(NULL, " ");
	}


	
	int from;
	char symbol;
	int to;
	while (fscanf(stdin, "%d %c %d", &from, &symbol, &to) != EOF) {		// scaning the input file
		trans_Map[from][symbol-'a'] = to; // add transition
										// transitions is ready
		
		all_Sts |= (1 << from); 
		all_Sts |= (1 << to);	//allStates bitset
	}

	
	reachable = 0;
	dfs(start_sts);
				// initialize reachable states
	
	all_Sts &= reachable;
	final_Sts &= reachable;	// filtering unreachable states

	
	P =  (long int*) malloc(64*sizeof(long int));
	for (int i = 0; i < 64 ; i++){			// initialize array bitsets
		P[i] = 0; 				//finds the partition exists
	}

	non_final_Sts = all_Sts & ~final_Sts;
	P[0] = final_Sts;				//final states and non-final states
	P[1] = non_final_Sts;

	int nextPartitionIndex = 2; 	// Store partitions have been added already
 
	for (int i = 0; i < 64; i++){		// partition is read add

		long int newPartition = 0;	// This partition will include all states

		if (P[i] == 0){		//partitioning
			break;
		}

		for (int j = 63; j >=  0; j--) 
		{		// looping for partition

			long int staticState = (long int) 1 << j;	// Potential leftmost bit.
			if ((P[i] & (staticState)) != 0)
			{
				parti_trans_Map[i] = trans_Map[j];

				for (int k = j - 1; k >= 0; k -- )
				{					// All states will be ready
					long int otherState = (long int) 1 << k;	// Potential state to remove

					
					if ((P[i] & (otherState)) != 0)		// Check if this state is in the current bitset
					{
						for (int l  = 0; l < 26; l++){
						int staticNext = -1; // next partition for static
						int otherNext = -1; // next partition for other
						for (int m = 0; m < nextPartitionIndex; m++)
						{
							if ((P[m] & (1 << trans_Map[j][l])) != 0)	//loop for transaction mapping
							{
								staticNext = m;	//static next state
							}
							if ((P[m] & (1 << trans_Map[k][l])) != 0)	//loop for transaction mapping
							{
								otherNext = m; // next state
							}
						}
													
						if (trans_Map[j][l] != trans_Map[k][l] && (staticNext != otherNext))
						{
							P[i] &= ~(1 << k);
							newPartition |= (1 << k);
							break;
						} 
					}	
				}
			}
				break;
		    }
		}

		if (newPartition != 0)	// partition is not equal
		{
			P[nextPartitionIndex] = newPartition;	//find new partition
			nextPartitionIndex++;
		}
	}
	int startPartition = 0;
	for (int i = 0; i < nextPartitionIndex; i ++)	// start fron starting the partition
	{
		if ((P[i] & (1 << start_sts)) != 0 )	// find and print start partition
		{
			startPartition = i;
			break;
		}
	}

	printf("%d \n", startPartition);

	for (int i = 0; i < nextPartitionIndex; i++)	// print final all partitions
	{
		if ((P[i] & final_Sts) != 0)
		{
			printf("%d ", i);
		}
	}
	printf("\n");
	for (int i = 0; i < nextPartitionIndex; i++)  //loop for next Partition Index
	{
		for (int j = 0; j < 26; j++) 						// find and print all transitions
		{
			if (parti_trans_Map[i][j] != -1)
			{					
				for (int k = 0; k < nextPartitionIndex; k++)		// print all transitions
				{
					if ((P[k] & (1 << parti_trans_Map[i][j])) != 0)
					{
						printf("%d %c %d\n", i, j + 'a', k);	// All transitions
						printf("ACCEPTED");
					}
					else
					{
						printf("REJECTED");
					}
				}
			}
		}
	}

	return 0;

}
//function call
void dfs(int v)
{
	reachable |= (1 << v);	// Try exploring all paths
	
	
	for(int i=0; i<26; i++)		//loop for the dfa states
		if((trans_Map[v][i] != -1) && ((reachable & (1 << trans_Map[v][i])) == 0))	// Try all paths..
		{
			dfs(trans_Map[v][i]);	//check all the states
		}
}
