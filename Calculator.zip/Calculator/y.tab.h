/* A Bison parser, made by GNU Bison 3.2.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    NUMBER = 258,
    L_BRACKET = 259,
    R_BRACKET = 260,
    DIV = 261,
    MUL = 262,
    ADD = 263,
    SUB = 264,
    EQUALS = 265,
    PI = 266,
    POW = 267,
    SQRT = 268,
    FACTORIAL = 269,
    MOD = 270,
    LOG2 = 271,
    LOG10 = 272,
    FLOOR = 273,
    CEIL = 274,
    ABS = 275,
    GBP_TO_USD = 276,
    USD_TO_GBP = 277,
    GBP_TO_EURO = 278,
    EURO_TO_GBP = 279,
    USD_TO_EURO = 280,
    EURO_TO_USD = 281,
    COS = 282,
    SIN = 283,
    TAN = 284,
    COSH = 285,
    SINH = 286,
    TANH = 287,
    CEL_TO_FAH = 288,
    FAH_TO_CEL = 289,
    M_TO_KM = 290,
    KM_TO_M = 291,
    VAR_KEYWORD = 292,
    VARIABLE = 293,
    EOL = 294
  };
#endif
/* Tokens.  */
#define NUMBER 258
#define L_BRACKET 259
#define R_BRACKET 260
#define DIV 261
#define MUL 262
#define ADD 263
#define SUB 264
#define EQUALS 265
#define PI 266
#define POW 267
#define SQRT 268
#define FACTORIAL 269
#define MOD 270
#define LOG2 271
#define LOG10 272
#define FLOOR 273
#define CEIL 274
#define ABS 275
#define GBP_TO_USD 276
#define USD_TO_GBP 277
#define GBP_TO_EURO 278
#define EURO_TO_GBP 279
#define USD_TO_EURO 280
#define EURO_TO_USD 281
#define COS 282
#define SIN 283
#define TAN 284
#define COSH 285
#define SINH 286
#define TANH 287
#define CEL_TO_FAH 288
#define FAH_TO_CEL 289
#define M_TO_KM 290
#define KM_TO_M 291
#define VAR_KEYWORD 292
#define VARIABLE 293
#define EOL 294

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 19 "calc.y" /* yacc.c:1912  */

	int index;
	double num;

#line 140 "y.tab.h" /* yacc.c:1912  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
