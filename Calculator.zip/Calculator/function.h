#ifndef FUNC_H
#define FUNC_H


/* Note: The currency conversion rates may change according to time */

// Convert GBP to USD	 
double gbp_to_usd(double gbp)   { return gbp * 1.28; }
// Convert GBP to EURO
double gbp_to_euro(double gbp)  { return gbp * 1.13; }

// Convert USD to GBP
double usd_to_gbp(double usd)   { return usd * 0.78; }
// Convert USD to EURO
double usd_to_euro(double usd)  { return usd * 0.88; }

// Convert EURO to GBP
double euro_to_gbp(double euro) { return euro * 0.89; }
// Convert EURO to USD
double euro_to_usd(double euro) { return euro * 1.13; }

// Convert celsius to fahrenheit
double cel_to_fah(double cel) 	{ return cel * 9 / 5 + 32; }
// Convert fahrenheit to celsius
double fah_to_cel(double fah) 	{ return (fah - 32) * 5 / 9; }

// Convert kilometers to miles
double km_to_m(double km) 		  { return km * 0.62137;}
// Convert miles to kilometers 
double m_to_km(double m)  		  { return m / 0.62137;} 

// Calculate factorial
double factorial(double n) 
{
	double x; double f=1;
	
	for (x=1; x<=n; x++) { 
		f *= x; 
	}
	
	return f;
}

// Calculate modulus
int modulo(double x, double y) 
{
	return (int)x % (int)y;
}

#endif
